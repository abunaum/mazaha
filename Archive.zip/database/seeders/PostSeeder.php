<?php

namespace Database\Seeders;

use App\Models\Post;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            [
                'categori' => 1,
                'author' => 1,
                'judul' => 'Kemah Blok Ada Lagi, Nun Alex: Ini Tarbiyah dan Pembentukan Karakter',
                'slug' => 'kemah-blok-ada-lagi-nun-alex-ini-tarbiyah-dan-pembentukan-karakter',
                'excerpt' => 'Setelah sempat ditiadakan selama tiga tahun karena pandemi Covid-19, Madrasah Aliyah Zainul Hasan 1 Genggong kembali melangsungkan Kemah Blok. Kegiatan yang dikhususkan kepada santri kelas X ini dilaksanakan pada 16-17 November untuk santri putri dan 19-21 November untuk santri putra.Bertempat di Bermi, Krucil, Probolinggo, Kemah Blok dilaksanakan...',
                'body' => '<p class="ql-align-justify"><span style="background-color: rgb(255, 255, 255);">Setelah sempat ditiadakan selama tiga tahun karena pandemi Covid-19, Madrasah Aliyah Zainul Hasan 1 Genggong kembali melangsungkan Kemah Blok. Kegiatan yang dikhususkan kepada santri kelas X ini dilaksanakan pada 16-17 November untuk santri putri dan 19-21 November untuk santri putra.</span></p><p class="ql-align-justify"><span style="background-color: rgb(255, 255, 255);">Bertempat di Bermi, Krucil, Probolinggo, Kemah Blok dilaksanakan dengan berbagai rangkaian kegiatan. Diantaranya pemberian materi Teknik Kepramukaan, Pendidikan Kemandirian, Pendidikan Jasmani dan Fisik, dan Pendidikan Rohani. Sedangkan puncak dari kegiatan ini adalah pelantikan penerimaan Tamu Ambalan menuju Anggota Ambalan yang ditujukan kepada santri baru MA Zaha.</span></p><p class="ql-align-justify">Nun Alex sebagai Kepala Madrasah mengatakan bahwa Kemah Blok adalah bagian dari tarbiyah dan pembentukan karakter santri untuk disiplin, giat, terampil, kreatif, dan siaga. Pihaknya juga menegaskan kegiatan tahunan ini juga implementasi kurikulum 2013 Permendikbud No. 63 Tahun 2014 tentang Kepramukaan.</p><p class="ql-align-justify">“Sengaja di Bermi, biar anak-anak menyatu dengan alam dan bertadabbur atas ciptaan Allah,” jelasnya saat ditanya alasan perkemahan ditempatkan di daerah pegunungan.</p><p class="ql-align-justify">Menurut Ustaz Bambang Dwi, antusiasme santri selama mengikuti kegiatan sangat bagus. “Meski sempat hujan, tapi mereka tetap semangat,” pungkasnya<strong>.(en)</strong></p>',
                'gambar' => 'gambar-post/CYWbHrfBFD5uMzx8YG6bWunLEtWXcRPdmwSa95k9.jpg',
            ],
            [
                'categori' => 3,
                'author' => 1,
                'judul' => 'Dua Santri MA Zaha Raih Juara 1 Pemrograman GIM',
                'slug' => 'dua-santri-ma-zaha-raih-juara-1-pemrograman-gim',
                'excerpt' => 'Lagi-lagi santri Madrasah Aliyah Zainul Hasan 1 Genggong menorehkan prestasi di bidang Teknologi Informatika. Elok Faiqoh dan Siti Ma’rifatul Khoir, dua santri kelas XII IPAini dinobatkan sebagai Juara 1 Lomba Pemrograman GIM pada ajang Procommit V.12 di Institut Teknologi Sepuluh November (ITS) Surabaya, Sabtu (26/11/2022).Procommit adalah singkat...',
                'body' => '<p class="ql-align-justify"><span style="background-color: rgb(242, 255, 222); color: rgb(103, 103, 103);">Lagi-lagi santri Madrasah Aliyah Zainul Hasan 1 Genggong menorehkan prestasi di bidang Teknologi Informatika. Elok Faiqoh dan Siti Ma’rifatul Khoir, dua santri kelas XII IPAini dinobatkan sebagai Juara 1 Lomba Pemrograman GIM pada ajang Procommit V.12 di Institut Teknologi Sepuluh November (ITS) Surabaya, Sabtu (26/11/2022).</span></p><p class="ql-align-justify"><span style="background-color: rgb(242, 255, 222); color: rgb(103, 103, 103);">Procommit adalah singkatan dari Prodistik Competition in IT, yang merupakan agenda tahunan Prodistik ITS Surabaya. Pesertanya berasal dari SMA/MA mitra ITS yang tersebar di Jawa Timur dan Jawa Tengah.</span></p><p class="ql-align-justify"><span style="background-color: rgb(242, 255, 222); color: rgb(103, 103, 103);">Sebelumnya Elok dan Khoir mengikuti babak penyisihan secara online pada 19/11/2022 dengan mengerjakan 2 produk GIM. Bersaing dengan 32 tim dari sekolah dan madrasah kemitraan Prodistik ITS Surabaya, tim dari MA Zaha berhasil lolos ke babak final bersama 14 tim lainnya.</span></p><p class="ql-align-justify"><span style="background-color: rgb(242, 255, 222); color: rgb(103, 103, 103);">Di babak final, keduanya diuji lagi mengerjakan 3 produk GIM dan berhasil menjadi 3 tim terbaik karena ketepatan dan kecepatannya menyelesaikan produk dibanding sekolah lain. 3 tim terbaik ini diberi kesempatan untuk presentasi, hingga akhirnya terpilihlah MA Zaha menjadi Juara 1 Pemrograman GIM Procommit V.12 tahun 2022.</span></p><p class="ql-align-justify"><span style="background-color: rgb(242, 255, 222); color: rgb(103, 103, 103);">Nun Alex, Kepala Madrasah yang turut hadir dan mendampingi ke ITS Surabaya mengaku sangat bangga atas capaian Prodistik MA Zaha tahun ini. “Mabruk. Ini ajang bergengsi, apalagi bidangnya programming. Bukti bahwa Madrasah dari Pesantren juga tidak kalah di bidang ini,” sanjungnya.</span></p><p class="ql-align-justify"><span style="background-color: rgb(242, 255, 222); color: rgb(103, 103, 103);"><span class="ql-cursor">﻿</span>Procommit memang dilaksanakan secara online selama dua tahun terakhir karena pandemi Covid-19. “Alhamdulillah, tahun ini mulai digelar offline lagi, lomba pemograman GIM pertama, dan kita langsung juara 1. Ini karena kegigihan peserta dan pembinanya,” imbuh Nun Alex.(en)</span></p><p><br></p>',
                'gambar' => 'gambar-post/voQ2vvw5AjaBTXPsETgHPVhkgk3KTa2zjsAeOIvL.jpg',
            ],
        ];
        foreach ($data as $d) {
            $newdata = [
                'categori' => $d['categori'],
                'author' => $d['author'],
                'judul' => $d['judul'],
                'slug' => $d['slug'],
                'excerpt' => $d['excerpt'],
                'body' => $d['body'],
                'gambar' => $d['gambar']
            ];
            Post::create($newdata);
            sleep(3);
        }
    }
}
