<li class="nav-heading">Master Data</li>
<li class="nav-item">
    <a class="nav-link <?php if(!isset($tab)): ?> collapsed <?php elseif($tab !== 'Data Person'): ?> collapsed <?php endif; ?>" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-menu-button-wide"></i><span>Data Person</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="components-nav" class="nav-content collapse <?php if(isset($tab)): ?> <?php if($tab === 'Data Person'): ?> show <?php endif; ?> <?php endif; ?>" data-bs-parent="#sidebar-nav">
        <li>
            <a href="<?php echo e($url_panel.'/admin/guru-staff'); ?>" <?php if($pages === 'Guru & Staff'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Guru & Staff</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e($url_panel.'/admin/siswa'); ?>" <?php if($pages === 'Siswa'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Siswa</span>
            </a>
        </li>
    </ul>
</li>
<li class="nav-item">
    <a class="nav-link <?php if(!isset($tab)): ?> collapsed <?php elseif($tab !== 'Data KBM'): ?> collapsed <?php endif; ?>" data-bs-target="#kbm-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-menu-button-wide"></i><span>Data KBM</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="kbm-nav" class="nav-content collapse <?php if(isset($tab)): ?> <?php if($tab === 'Data KBM'): ?> show <?php endif; ?> <?php endif; ?>" data-bs-parent="#sidebar-nav">
        <li>
            <a href="<?php echo e($url_panel.'/admin/kelas'); ?>" <?php if($pages === 'Kelas'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Kelas</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e($url_panel.'/admin/mapel'); ?>" <?php if($pages === 'Mapel'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Mapel</span>
            </a>
        </li>
    </ul>
</li>

<li class="nav-heading">Pages</li>

<li class="nav-item">
    <a class="nav-link collapsed" href="users-profile.html">
        <i class="bi bi-person"></i>
        <span>Profile</span>
    </a>
</li><!-- End Profile Page Nav -->

<?php /**PATH /home/abunaum/Documents/ma-laravel/resources/views/panel/sidebar/admin.blade.php ENDPATH**/ ?>