<html>
<head>
    <title>Test</title>
</head>
<body>
<h1>Done : </h1>
<p id="done"></p>
<script
    src="https://code.jquery.com/jquery-3.6.3.min.js"
    integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU="
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script>
    $(document).ready(function () {
        const id = <?= json_encode($id); ?>;
        const satu = document.getElementById("done");
        satu.innerHTML = 0;
        id.forEach(async function (idnya) {

            await fetch("https://api.cloudflare.com/client/v4/zones/417e045f4e5d0bf7f1476b2de1b80c52/dns_records/"+ idnya, {
                headers: {
                    "X-Auth-Email": "ahmad.yani.ardath@gmail.com",
                    "X-Auth-Key": "f9546f0b658f777e54a3f920f6dd2c9dd5e6f"
                },
                method: "DELETE"
            }).then(function (response) {
                const nominal = document.getElementById("done");
                const nominalval = nominal.innerHTML;
                const baru = parseInt(nominalval) + 1;
                nominal.innerHTML = baru;
                return response.json();
            }).then(function (data) {
                console.log(data);
            });
        });
    });
</script>
</body>
</html>
<?php /**PATH /home/abunaum/Documents/ma-laravel/resources/views/test.blade.php ENDPATH**/ ?>