<?php $__env->startSection('content'); ?>
    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container mt-3">
            <center>
                <h2>Media Informasi MA Zainul Hasan 1</h2>
            </center>
        </div>
    </div>
    <section>
        <div class="container" data-aos="fade-up">
            <?php if($posts->count()): ?>
                <div class="card mb-3">
                    <div style="max-height: 350px; overflow: hidden">
                        <img class="card-img-top" src="<?php echo e(asset('storage/'.$posts[0]->gambar)); ?>" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <center>
                            <h2 class="card-title"><?php echo e($posts[0]->judul); ?></h2>
                            <p class="card-text mb-3"><small
                                    class="text-muted">Diposting <?php echo e(\Carbon\Carbon::parse($posts[0]->created_at)->diffForHumans()); ?>

                                    . By <?php echo e($posts[0]->nama_author); ?> | Kategori : <?php echo e($posts[0]->nama_kategori); ?></small>
                            </p>
                        </center>
                        <p class="card-text"><?php echo e($posts[0]->excerpt); ?></p>
                        <center>
                            <a href="<?php echo e(url('/berita/detail/', $posts[0]->slug)); ?>" class="btn btn-primary mb-3">Baca
                                Selengkapnya</a>
                        </center>
                    </div>
                </div>
            <?php else: ?>
                <center>
                    <h1>Post tidak ditemukan.</h1>
                </center>
            <?php endif; ?>
        </div>
        <div class="container" data-aos="fade-up">
            <div class="row">
                <?php $__currentLoopData = $posts->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('storage/'.$post->gambar)); ?>" alt="Gambar">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($post->judul); ?></h5>
                                <p class="ql-align-justify"><?php echo e(Str::limit($post->excerpt, 200, '...')); ?></p>
                                <a href="<?php echo e(url('/berita/detail/', $post->slug)); ?>" class="btn btn-primary mb-3">Baca
                                    Selengkapnya</a>
                                <p class="card-text"><small
                                        class="text-muted">Diposting <?php echo e(\Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?>

                                        . By <?php echo e($post->nama_author); ?> | Kategori : <?php echo e($post->nama_kategori); ?></small>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abunaum/Documents/ma-laravel/resources/views/berita.blade.php ENDPATH**/ ?>