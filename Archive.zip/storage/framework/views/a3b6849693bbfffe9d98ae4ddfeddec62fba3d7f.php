<nav id="navbar" class="navbar">
    <ul>
        <li><a class="nav-link scrollto <?php echo e(($pages === 'home') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a class="nav-link scrollto <?php echo e(($pages === 'profile') ? 'active' : ''); ?>" href="<?php echo e(url('/profile')); ?>">Profile</a></li>
        <li><a class="nav-link scrollto <?php echo e(($pages === 'visi-misi') ? 'active' : ''); ?>" href="<?php echo e(url('/visi-misi')); ?>">Visi-Misi</a></li>
        <li><a class="nav-link scrollto <?php echo e(($pages === 'staff-pengajar') ? 'active' : ''); ?>" href="<?php echo e(url('/staff-pengajar')); ?>">Staff Pengajar</a></li>
        <li><a class="nav-link scrollto" href="https://ppsb.mazainulhasan1.sch.id" target="_blank">PSB</a></li>

        <li><a class="nav-link scrollto <?php echo e(($pages === 'berita') ? 'active' : ''); ?>" href="<?php echo e(url('/berita')); ?>">Berita</a></li>
        <li><a class="getstarted scrollto" href="https://simumtaz.mazainulhasan1.sch.id" target="_blank">SIMUMTAZ</a></li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav>
<?php /**PATH /home/abunaum/Documents/ma-laravel/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>